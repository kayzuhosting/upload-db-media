### Announcement✨
---
#### **INDONESIA:**
***saya raol mukarrozi akan terus me update fitur bot discord ini mungkin juga bakal menambahkan agar support bot telegram😉***
#### **ENGLISH:**
***I, Raol Mukarrozi, will continue to update the Discord bot feature, maybe I will also add support for Telegram bots😉***
