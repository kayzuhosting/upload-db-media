### Announcement✨
---
#### **INDONESIA:**
***jangan lupa fork github repository😜 agar mendapatkan notif update lebih lanjut***
### **ENGLISH:**
***don't forget to fork the github repository😜 to get further update notifications***
