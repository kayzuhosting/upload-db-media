module.exports = {
  discordToken: 'your_discord_bot_token_here',
};